# DeepTFni
DeepTFni is a [VGAE](https://arxiv.org/abs/1611.07308)-based model to infer transcription factor regulatory network (TRN). DeepTFni requires scATAC-seq peak count matrix as the input and generates an adjacency matrix for the inferred TRN.    

# System requirements
* Linux/Unix.  
* Perl (v5.26.1) for DeepTFni Perl script.  
* Python (>= 3.7) for DeepTFni workflow, v3.7.8 is recommanded.  
* [Pytorch](https://pytorch.org/) (v1.4.0).  
* R (>= 4.0.3) for DeepTFni R script, v4.0.3 is recommanded.  
* bedops (v2.4.26).  
* fimo.  

# Package dependencies
##  For Perl
* BioPerl (v1.7.4).  
* Parallel::ForkManager (recommanded for parallel processing).  
##  For Python
* numpy (v1.17.3).    
* pandas (v1.1.3).  
* scipy (v1.4.1).  
* scikit-learn (v0.23.2).  
* h5py (v2.10.0).  
##  For R
* [MAESTRO](https://github.com/liulab-dfci/MAESTRO) (v1.2.1).  

# Usage
Here, we will show you how to run through the whole DeepTFni pipeline from the scATAC-seq matrix to the final inferred TRN.

##  Step 0. Prepare the environment
Before running DeepTFni, users need to activate the MAESTRO environment.  
```
$ conda activate MAESTRO
```  
##  Step 1. Process the data and train DeepTFni model
And then users can preprocess their scATAC-seq matrix and train DeepTFni model through the command:  

```
$ perl run_DeepTFni_csv.pl ./Input_data/
```
`./Input_data/` is the path to scATAC-seq matrix in csv format ([How to prepare your input](https://github.com/sunyolo/DeepTFni/tree/main/demo)).  

Then a chain of scripts would run automatically in following order:

  * to_generate_initial_adj_matrix: from `1-ATAC_peak.pl` to `5-GetMatrix.pl` in [./preprocessing/](https://github.com/sunyolo/DeepTFni/tree/main/preprocessing).
  * to generate regulatory potential score using MAESTRO: from `6_dense_matrix_2_h5_for_MAESTRO_input.py` to `7_for_TF_rp_score.R` in [./preprocessing/](https://github.com/sunyolo/DeepTFni/tree/main/preprocessing) .
  * to split dataset, train DeepTFni model and organize the output: from `8_data_preparation_for_DeepTFni.py` to `11_integrated_output.py` in [./](https://github.com/sunyolo/DeepTFni).

##  Step 2. Understand the output
The final output is a reconstructed adjacency matrix in .txt format named `adj_matrix_predicted_binary_final_integrated_from_20_replicates.txt`. It locates in `Path to project/train_info/result_k_10_summary/`. 
